<template>
  <n-layout class="h-full">
    <n-layout-header>颐和园路</n-layout-header>
    <n-layout-content class="h-full" content-style="padding: 24px;"> 平山道 </n-layout-content>
  </n-layout>
</template>
