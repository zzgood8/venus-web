const BasicLayout = () => import('./index.vue')

export { BasicLayout }
