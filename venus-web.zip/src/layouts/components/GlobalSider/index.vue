<template>
  <ul>
    <li>系统管理</li>
    <li>用户设置</li>
    <li>视图管理</li>
    <li>路由菜单</li>
  </ul>
</template>