import GlobalContent from './GlobalContent/index.vue'
import GlobalHeader from './GlobalHeader/index.vue'
import GlobalSider from './GlobalSider/index.vue'
import GlobalTab from './GlobalTab/index.vue'

export { GlobalContent, GlobalHeader, GlobalSider, GlobalTab }
